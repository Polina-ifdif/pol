package com.example.proekt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Cod : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cod)
    }
}