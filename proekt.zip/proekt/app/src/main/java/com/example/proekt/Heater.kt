package com.example.proekt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Heater : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_heater)
    }
}